// Header file for function exported from number.h

extern void print_number (int i);
