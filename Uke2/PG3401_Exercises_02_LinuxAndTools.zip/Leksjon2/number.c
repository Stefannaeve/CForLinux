#include <stdio.h>

void print_number (int i)
{
   printf ("Print a number: %d\n", i);
}
