//
// File: griseenkelt.c - Our first program!
//
// To compile: gcc -O2 griseenkelt.c -o griseenkelt
//

#include <stdio.h>

void main (void)
{
   printf ("Hello class!!\n");
}
