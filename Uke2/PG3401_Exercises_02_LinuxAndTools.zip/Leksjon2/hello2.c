#include <stdio.h>

void main (void)
{
   printf ("Hello class!!\n");
   TellOpp();
}

void TellOpp (void)
{
   for (int i = 0; i < 5; i++) {
      printf ("Vi teller %d\n", i);
   }   
}   


